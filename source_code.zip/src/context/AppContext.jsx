import React, { createContext, useContext, useState, useEffect } from 'react';
import { translations } from '../data/translations';
import { initialData } from '../data/initialData';

const AppContext = createContext();

export function AppProvider({ children }) {
  const [lang, setLang] = useState(() => localStorage.getItem('fc_lang') || 'ru');
  const [news, setNews] = useState(() => {
    const saved = localStorage.getItem('fc_news');
    return saved ? JSON.parse(saved) : initialData.news;
  });
  const [teamsData, setTeamsData] = useState(() => {
    const saved = localStorage.getItem('fc_teams_v2');
    return saved ? JSON.parse(saved) : initialData.teams;
  });
  const [videos, setVideos] = useState(() => {
    const saved = localStorage.getItem('fc_videos');
    return saved ? JSON.parse(saved) : initialData.videos;
  });
  const [photos, setPhotos] = useState(() => {
    const saved = localStorage.getItem('fc_photos');
    return saved ? JSON.parse(saved) : initialData.photos;
  });
  const [trialApplications, setTrialApplications] = useState(() => {
    const saved = localStorage.getItem('fc_trials');
    return saved ? JSON.parse(saved) : [
      { id: 1, fullName: "Марк Петров", birthYear: "2009", parentName: "Олег Петров", phone: "+48 555 123 456", email: "oleg@example.com", preferredTeam: "2009", date: "2026-07-23" }
    ];
  });
  const [siteSettings, setSiteSettings] = useState(() => {
    const saved = localStorage.getItem('fc_site_settings');
    if (saved) {
      let parsed = JSON.parse(saved);
      if (parsed.historyText) {
        let changed = false;
        if (parsed.historyText.includes(' Legia Warszawa')) {
          parsed.historyText = parsed.historyText.split(' Legia Warszawa')[0] + '.';
          changed = true;
        }
        if (parsed.historyText.includes(' Legii Warszawa')) {
          parsed.historyText = parsed.historyText.split(' Legii Warszawa')[0] + '.';
          changed = true;
        }
        if (parsed.historyText.includes(' of Legia Warszawa')) {
          parsed.historyText = parsed.historyText.split(' of Legia Warszawa')[0] + '.';
          changed = true;
        }
        if (changed) {
          // Clean up multiple dots if any
          parsed.historyText = parsed.historyText.replace('..', '.');
          localStorage.setItem('fc_site_settings', JSON.stringify(parsed));
        }
      }
      return parsed;
    }
    return {
      heroTitle: "FOOTBALL CHALLENGE",
      heroSubtitle: "АКАДЕМИЯ ЧЕМПИОНОВ",
      heroDescription: "Профессиональная подготовка, дисциплина и характер. Твой путь в большой футбол начинается здесь.",
      heroButtonText: "ЗАПИСАТЬСЯ НА ПРОСМОТР",
      heroImage: "https://images.unsplash.com/photo-1518605368461-1eb47b2c0199?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80",
      aboutTitle: "О КЛУБЕ FOOTBALL CHALLENGE",
      aboutSubtitle: "История, миссия и философия развития молодых футболистов",
      aboutImage: "https://images.unsplash.com/photo-1526232761682-d26e03ac148e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
      historyTitle: "Наша История",
      historyText: "Football Challenge основан с целью создания современной спортивной экосистемы, где каждый ребенок получает возможность раскрыть свой потенциал под руководством лучших специалистов по европейским стандартам.",
      missionTitle: "Миссия и Ценности",
      missionText: "Воспитание не только профессиональных атлетов, но и сильных личностей. Мы прививаем дисциплину, командный дух, уважение и менталитет победителей.",
      contactPhone: "+48 600 123 456",
      contactEmail: "footballchallange@gmail.com",
      contactAddress: "ul. Sportowa 15, Warsaw",
      contactInsta: "https://instagram.com",
      contactTg: "https://t.me",
      contactFb: "",
      contactYt: "",
      contactTk: "",
      footerText: "Все права защищены. Копирование материалов сайта без разрешения запрещено."
    };
  });
  
  const [themeSettings, setThemeSettings] = useState(() => {
    const saved = localStorage.getItem('fc_theme_settings');
    return saved ? JSON.parse(saved) : {
      primaryColor: '#10b981'
    };
  });

  const [customTranslations, setCustomTranslations] = useState(() => {
    const saved = localStorage.getItem('fc_translations');
    return saved ? JSON.parse(saved) : translations;
  });
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(() => {
    return localStorage.getItem('fc_admin_auth') === 'true';
  });
  const [adminPassword, setAdminPassword] = useState(() => {
    return localStorage.getItem('fc_admin_pwd') || 'admin123';
  });
  
  const [coaches, setCoaches] = useState(() => {
    const saved = localStorage.getItem('fc_coaches');
    return saved ? JSON.parse(saved) : initialData.coaches;
  });
  
  const [partners, setPartners] = useState(() => {
    const saved = localStorage.getItem('fc_partners');
    return saved ? JSON.parse(saved) : initialData.partners;
  });

  const loginAdmin = (inputPassword) => {
    if (inputPassword === adminPassword) {
      setIsAdminAuthenticated(true);
      localStorage.setItem('fc_admin_auth', 'true');
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem('fc_admin_auth');
  };

  const changeAdminPassword = (newPwd) => {
    setAdminPassword(newPwd);
    localStorage.setItem('fc_admin_pwd', newPwd);
  };
  const [sponsorApplications, setSponsorApplications] = useState(() => {
    const saved = localStorage.getItem('fc_sponsors_req');
    return saved ? JSON.parse(saved) : [
      { id: 1, companyName: "TechCorp Poland", contactName: "Елена Смирнова", phone: "+48 777 888 999", email: "sponsorship@techcorp.pl", tier: "General Partner", date: "2026-07-24" }
    ];
  });

  // Modal States
  const [isTrialModalOpen, setIsTrialModalOpen] = useState(false);
  const [isSponsorModalOpen, setIsSponsorModalOpen] = useState(false);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [activeVideo, setActiveVideo] = useState(null);
  const [activePhoto, setActivePhoto] = useState(null);
  const [activeArticle, setActiveArticle] = useState(null);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('fc_lang', lang);
  }, [lang]);

  useEffect(() => {
    localStorage.setItem('fc_news', JSON.stringify(news));
  }, [news]);

  useEffect(() => {
    localStorage.setItem('fc_teams_v2', JSON.stringify(teamsData));
  }, [teamsData]);

  useEffect(() => {
    localStorage.setItem('fc_videos', JSON.stringify(videos));
  }, [videos]);

  useEffect(() => {
    localStorage.setItem('fc_photos', JSON.stringify(photos));
  }, [photos]);

  useEffect(() => {
    localStorage.setItem('fc_trials', JSON.stringify(trialApplications));
  }, [trialApplications]);

  useEffect(() => {
    localStorage.setItem('fc_sponsors_req', JSON.stringify(sponsorApplications));
  }, [sponsorApplications]);

  useEffect(() => {
    localStorage.setItem('fc_site_settings', JSON.stringify(siteSettings));
  }, [siteSettings]);

  useEffect(() => {
    localStorage.setItem('fc_coaches', JSON.stringify(coaches));
  }, [coaches]);

  useEffect(() => {
    localStorage.setItem('fc_theme_settings', JSON.stringify(themeSettings));
    
    // Apply dynamic colors by overriding tailwind v4 emerald palette
    const hex = themeSettings.primaryColor || '#10b981';
    
    const shadeColor = (color, percent) => {
      let R = parseInt(color.substring(1,3),16);
      let G = parseInt(color.substring(3,5),16);
      let B = parseInt(color.substring(5,7),16);

      R = parseInt(R * (100 + percent) / 100);
      G = parseInt(G * (100 + percent) / 100);
      B = parseInt(B * (100 + percent) / 100);

      R = (R<255)?R:255;  
      G = (G<255)?G:255;  
      B = (B<255)?B:255;  

      R = Math.round(R);
      G = Math.round(G);
      B = Math.round(B);

      let RR = ((R.toString(16).length===1)?"0"+R.toString(16):R.toString(16));
      let GG = ((G.toString(16).length===1)?"0"+G.toString(16):G.toString(16));
      let BB = ((B.toString(16).length===1)?"0"+B.toString(16):B.toString(16));

      return "#"+RR+GG+BB;
    };

    document.documentElement.style.setProperty('--color-emerald-300', shadeColor(hex, 40));
    document.documentElement.style.setProperty('--color-emerald-400', shadeColor(hex, 20));
    document.documentElement.style.setProperty('--color-emerald-500', hex);
    document.documentElement.style.setProperty('--color-emerald-600', shadeColor(hex, -20));
    document.documentElement.style.setProperty('--color-emerald-900', shadeColor(hex, -60));
    document.documentElement.style.setProperty('--color-emerald-950', shadeColor(hex, -80));
    
  }, [themeSettings]);

  useEffect(() => {
    localStorage.setItem('fc_translations', JSON.stringify(customTranslations));
  }, [customTranslations]);

  const t = customTranslations[lang] || customTranslations.ru;

  const addNews = (item) => {
    const newArticle = { ...item, id: Date.now() };
    setNews([newArticle, ...news]);
  };

  const deleteNews = (id) => {
    setNews(news.filter(n => n.id !== id));
  };

  const addTrialApp = (app) => {
    const newApp = { ...app, id: Date.now(), date: new Date().toISOString().split('T')[0] };
    setTrialApplications([newApp, ...trialApplications]);
  };

  const addSponsorApp = (app) => {
    const newApp = { ...app, id: Date.now(), date: new Date().toISOString().split('T')[0] };
    setSponsorApplications([newApp, ...sponsorApplications]);
  };

  const addPhoto = (photo) => {
    const newP = { ...photo, id: Date.now() };
    setPhotos([newP, ...photos]);
  };

  const addVideo = (vid) => {
    const newV = { ...vid, id: Date.now() };
    setVideos([newV, ...videos]);
  };

  const addPlayer = (teamYear, player) => {
    setTeamsData(prev => {
      const newData = { ...prev };
      if (!newData[teamYear]) return prev;
      newData[teamYear].roster = [
        ...newData[teamYear].roster,
        { ...player, id: Date.now() }
      ];
      return newData;
    });
  };

  const updatePlayer = (teamYear, playerId, updatedPlayer) => {
    setTeamsData(prev => {
      const newData = { ...prev };
      if (!newData[teamYear]) return prev;
      newData[teamYear].roster = newData[teamYear].roster.map(p => 
        p.id === playerId ? { ...p, ...updatedPlayer } : p
      );
      return newData;
    });
  };

  const deletePlayer = (teamYear, playerId) => {
    setTeamsData(prev => {
      const newData = { ...prev };
      if (!newData[teamYear]) return prev;
      newData[teamYear].roster = newData[teamYear].roster.filter(p => p.id !== playerId);
      return newData;
    });
  };

  const updateTeamCoach = (teamYear, coachData) => {
    setTeamsData(prev => {
      const newData = { ...prev };
      if (!newData[teamYear]) return prev;
      newData[teamYear].coach = coachData;
      return newData;
    });
  };

  const addTeamSchedule = (teamYear, match) => {
    setTeamsData(prev => {
      const newData = { ...prev };
      if (!newData[teamYear]) return prev;
      newData[teamYear].schedule = [...(newData[teamYear].schedule || []), { ...match, id: Date.now() }];
      return newData;
    });
  };
  const deleteTeamSchedule = (teamYear, matchId) => {
    setTeamsData(prev => {
      const newData = { ...prev };
      if (!newData[teamYear]) return prev;
      newData[teamYear].schedule = (newData[teamYear].schedule || []).filter(s => s.id !== matchId);
      return newData;
    });
  };

  const addTeamResult = (teamYear, match) => {
    setTeamsData(prev => {
      const newData = { ...prev };
      if (!newData[teamYear]) return prev;
      newData[teamYear].results = [...(newData[teamYear].results || []), { ...match, id: Date.now() }];
      return newData;
    });
  };
  const deleteTeamResult = (teamYear, matchId) => {
    setTeamsData(prev => {
      const newData = { ...prev };
      if (!newData[teamYear]) return prev;
      newData[teamYear].results = (newData[teamYear].results || []).filter(r => r.id !== matchId);
      return newData;
    });
  };

  const updateTeamStandings = (teamYear, newStandings) => {
    setTeamsData(prev => {
      const newData = { ...prev };
      if (!newData[teamYear]) return prev;
      newData[teamYear].standings = newStandings;
      return newData;
    });
  };

  const updateSiteSettings = (newSettings) => {
    setSiteSettings(prev => ({ ...prev, ...newSettings }));
  };

  const addCoach = (coach) => {
    const newCoach = { ...coach, id: Date.now() };
    setCoaches([...coaches, newCoach]);
  };

  const updateCoach = (id, updated) => {
    setCoaches(coaches.map(c => c.id === id ? { ...c, ...updated } : c));
  };

  const deleteCoach = (id) => {
    setCoaches(coaches.filter(c => c.id !== id));
  };

  const addPartner = (partner) => {
    const newPartner = { ...partner, id: Date.now() };
    setPartners([...partners, newPartner]);
  };

  const deletePartner = (id) => {
    setPartners(partners.filter(p => p.id !== id));
  };

  return (
    <AppContext.Provider value={{
      lang,
      setLang,
      t,
      news,
      teamsData,
      videos,
      photos,
      trialApplications,
      sponsorApplications,
      isTrialModalOpen,
      setIsTrialModalOpen,
      isSponsorModalOpen,
      setIsSponsorModalOpen,
      isAdminModalOpen,
      setIsAdminModalOpen,
      isAdminAuthenticated,
      loginAdmin,
      logoutAdmin,
      changeAdminPassword,
      activeVideo,
      setActiveVideo,
      activePhoto,
      setActivePhoto,
      activeArticle,
      setActiveArticle,
      addNews,
      deleteNews,
      addTrialApp,
      addSponsorApp,
      addPhoto,
      addVideo,
      addPlayer,
      updatePlayer,
      deletePlayer,
      updateTeamCoach,
      addTeamSchedule,
      deleteTeamSchedule,
      addTeamResult,
      deleteTeamResult,
      updateTeamStandings,
      siteSettings,
      updateSiteSettings,
      coaches,
      addCoach,
      updateCoach,
      deleteCoach,
      partners,
      addPartner,
      deletePartner,
      themeSettings,
      setThemeSettings,
      customTranslations,
      setCustomTranslations
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
